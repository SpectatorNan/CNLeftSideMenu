//
//  AppDelegate.h
//  CNLeftSideMenu-example
//
//  Created by spectator Mr.Z on 16/2/25.
//  Copyright © 2016年 spectator Mr.Z. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

