//
//  CNContentData.h
//  eathome
//
//  Created by spectator Mr.Z on 16/2/25.
//  Copyright © 2016年 test. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>


@interface CNContentData : NSObject

@property (nonatomic, strong) UIImage *image;

@property (nonatomic, strong) NSString *desc;



@end
